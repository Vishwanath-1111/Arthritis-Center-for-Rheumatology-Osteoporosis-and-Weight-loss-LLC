/**
 * healow Healthcare - Main JavaScript
 * Handles OWL Carousel, navigation, accordion, and interactive elements
 */

$(document).ready(function() {
    
    // Initialize OWL Carousel for Testimonials (only when cards exist)
    var $testimonialCarousel = $('.testimonial-carousel');
    if ($testimonialCarousel.length && $testimonialCarousel.children().length) {
        $testimonialCarousel.owlCarousel({
        loop: true,
        margin: 20,
        nav: true,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 2
            },
            992: {
                items: 3
            }
        },
        navText: [
            '<i class="fas fa-chevron-left"></i>',
            '<i class="fas fa-chevron-right"></i>'
        ]
        });
    }

    // Smooth scroll for anchor links
    $('a[href^="#"]').on('click', function(e) {
        const href = this.getAttribute('href');
        if (href === '#') return;
        const target = $(href);
        if (target.length) {
            e.preventDefault();
            $('html, body').stop().animate({
                scrollTop: target.offset().top - 80
            }, 600);
        }
    });

    // Navbar active state on scroll
    $(window).on('scroll', function() {
        const scrollPos = $(window).scrollTop();
        $('.main-nav .nav-link').each(function() {
            const link = $(this);
            const href = link.attr('href');
            if (!href || href === '#') return;
            const targetSection = $(href);
            if (targetSection.length) {
                const sectionTop = targetSection.offset().top - 100;
                const sectionBottom = sectionTop + targetSection.outerHeight();
                if (scrollPos >= sectionTop && scrollPos < sectionBottom) {
                    link.addClass('active');
                } else {
                    link.removeClass('active');
                }
            }
        });
    });

    // Tools tabs - highlight active tab on click
    $('.tools-tabs a').on('click', function(e) {
        e.preventDefault();
        $('.tools-tabs li').removeClass('active');
        $(this).closest('li').addClass('active');
    });

    // Mobile navbar collapse on link click
    $('.main-nav .nav-link').on('click', function() {
        if ($(window).width() < 992) {
            $('.navbar-collapse').collapse('hide');
        }
    });

    // Back to top button
    const $backToTop = $('#back-to-top');
    $(window).on('scroll', function() {
        if ($(window).scrollTop() > 400) {
            $backToTop.addClass('visible');
        } else {
            $backToTop.removeClass('visible');
        }
    });
    $backToTop.on('click', function() {
        $('html, body').animate({ scrollTop: 0 }, 600);
    });
});
